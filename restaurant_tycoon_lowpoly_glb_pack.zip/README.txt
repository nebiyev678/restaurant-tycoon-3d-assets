Restaurant Tycoon low-poly GLB asset pack
39 original procedural stylized 3D models based loosely on concept illustrations.
Units: meters; Z-up geometry (GLB importers may convert coordinates).
Vertex colors used; no external textures.
Models are separate static meshes, unrigged. Player is a static concept model, not animated.
Food parts are individual objects. These are stylized approximations, not exact reconstruction of the supplied concept images.
